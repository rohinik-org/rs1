import type {
  ExecutionStatusResponse,
  ExecutionResultResponse,
  ExecutionEvidenceResponse,
  CancelExecutionRequest,
  CancelExecutionResponse,
  PublicExecutionState,
} from '@rohinik-org/execution-protocol-v1'
import { PUBLIC_TERMINAL_STATES } from '@rohinik-org/execution-protocol-v1'
import { RohinikClientError } from './transport.js'
import type { HttpTransport } from './transport.js'

// ── Poll options ──────────────────────────────────────────────────────────────

export interface PollOptions {
  /** Milliseconds between status polls. Default: 500. */
  readonly pollIntervalMs?: number
  /** Milliseconds until the poll loop gives up and throws. Default: 30 000. */
  readonly timeoutMs?: number
  /** External abort signal — cancels the poll loop immediately when aborted. */
  readonly signal?: AbortSignal
  /** Called on every status response during the poll loop. */
  readonly onStatus?: (status: ExecutionStatusResponse) => void
}

// ── Terminal failure errors ───────────────────────────────────────────────────

export class ExecutionFailedError extends RohinikClientError {
  readonly executionId: string
  readonly terminalState: PublicExecutionState

  constructor(executionId: string, state: PublicExecutionState) {
    super(`Execution ${executionId} reached terminal state ${state}`)
    this.name = 'ExecutionFailedError'
    this.executionId = executionId
    this.terminalState = state
  }
}

export class ExecutionCancelledError extends ExecutionFailedError {
  constructor(executionId: string) {
    super(executionId, 'CANCELLED')
    this.name = 'ExecutionCancelledError'
  }
}

export class ExecutionTimeoutError extends RohinikClientError {
  readonly executionId: string

  constructor(executionId: string, timeoutMs: number) {
    super(`Execution ${executionId} did not reach terminal state within ${timeoutMs}ms`)
    this.name = 'ExecutionTimeoutError'
    this.executionId = executionId
  }
}

// ── ExecutionHandle ───────────────────────────────────────────────────────────

export class ExecutionHandle {
  readonly executionId: string

  constructor(
    executionId: string,
    private readonly transport: HttpTransport,
  ) {
    this.executionId = executionId
  }

  status(): Promise<ExecutionStatusResponse> {
    return this.transport.request<ExecutionStatusResponse>(
      'GET',
      `/v1/executions/${encodeURIComponent(this.executionId)}`,
    )
  }

  result(): Promise<ExecutionResultResponse> {
    return this.transport.request<ExecutionResultResponse>(
      'GET',
      `/v1/executions/${encodeURIComponent(this.executionId)}/result`,
    )
  }

  evidence(): Promise<ExecutionEvidenceResponse> {
    return this.transport.request<ExecutionEvidenceResponse>(
      'GET',
      `/v1/executions/${encodeURIComponent(this.executionId)}/evidence`,
    )
  }

  cancel(body?: CancelExecutionRequest): Promise<CancelExecutionResponse> {
    return this.transport.request<CancelExecutionResponse>(
      'POST',
      `/v1/executions/${encodeURIComponent(this.executionId)}/cancel`,
      body ?? {},
    )
  }

  /**
   * Poll status until terminal. Resolves with the terminal status response.
   * Throws ExecutionTimeoutError if timeoutMs elapses before terminal.
   */
  async waitUntilTerminal(options?: PollOptions): Promise<ExecutionStatusResponse> {
    const pollIntervalMs = options?.pollIntervalMs ?? 500
    const timeoutMs      = options?.timeoutMs      ?? 30_000
    const signal         = options?.signal
    const onStatus       = options?.onStatus

    const deadline = Date.now() + timeoutMs

    while (true) {
      if (signal?.aborted) {
        throw new RohinikClientError('Poll aborted via AbortSignal')
      }

      const status = await this.status()
      onStatus?.(status)

      if (PUBLIC_TERMINAL_STATES.has(status.state)) {
        return status
      }

      if (Date.now() >= deadline) {
        throw new ExecutionTimeoutError(this.executionId, timeoutMs)
      }

      await _sleep(pollIntervalMs, signal)
    }
  }

  /**
   * Poll until terminal, then return the execution result.
   *
   * - COMPLETED: resolves with ExecutionResultResponse
   * - FAILED:    throws ExecutionFailedError
   * - CANCELLED: throws ExecutionCancelledError
   * - timeout:   throws ExecutionTimeoutError
   */
  async waitForResult(options?: PollOptions): Promise<ExecutionResultResponse> {
    const status = await this.waitUntilTerminal(options)

    if (status.state === 'CANCELLED') {
      throw new ExecutionCancelledError(this.executionId)
    }
    if (status.state === 'FAILED') {
      throw new ExecutionFailedError(this.executionId, status.state)
    }

    return this.result()
  }
}

function _sleep(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(resolve, ms)
    signal?.addEventListener('abort', () => {
      clearTimeout(timer)
      reject(new RohinikClientError('Poll aborted via AbortSignal'))
    }, { once: true })
  })
}
