/**
 * Stage 16A Task 7 — Cross-Repository Protocol Conformance
 *
 * Verifies that:
 *   1. All five protocol routes return shapes matching the spec
 *   2. Unknown additive fields in responses are tolerated (forward-compat)
 *   3. Wrong protocolVersion in response throws ProtocolVersionError
 *   4. All PublicErrorCode values from the protocol package are handled
 *   5. The packed @rohinik-org/client tarball declares no runtime dependencies
 */

import { describe, it, expect, beforeAll, afterAll } from 'vitest'
import { createServer, type Server } from 'node:http'
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import {
  createRohinikClient,
  RohinikClientError,
  ProtocolVersionError,
  EXECUTION_PROTOCOL_VERSION,
  type PublicErrorCode,
} from '../index.js'

const CONF_PORT = 19_202

// ── Minimal protocol-conformant mock server ───────────────────────────────────

type MockState = {
  executionId: string
  state: string
  submittedAt: string
  startedAt: string | null
  completedAt: string | null
  cancelledAt: string | null
  output: unknown
  terminal: boolean
}

const store = new Map<string, MockState>()
let confServer: Server

function json(res: import('node:http').ServerResponse, status: number, body: unknown) {
  const payload = JSON.stringify(body)
  res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload).toString() })
  res.end(payload)
}

function readBody(req: import('node:http').IncomingMessage): Promise<Record<string, unknown>> {
  return new Promise(resolve => {
    const chunks: Buffer[] = []
    req.on('data', (c: Buffer) => chunks.push(c))
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString())) }
      catch { resolve({}) }
    })
  })
}

const proto = EXECUTION_PROTOCOL_VERSION

beforeAll(async () => {
  confServer = createServer(async (req, res) => {
    const url = req.url ?? ''
    const method = req.method ?? 'GET'

    if (method === 'POST' && url === '/v1/executions') {
      const body = await readBody(req)
      const executionId = `conf-exec-${Date.now()}-${Math.random().toString(36).slice(2)}`
      const now = new Date().toISOString()
      store.set(executionId, {
        executionId, state: 'QUEUED',
        submittedAt: now, startedAt: null, completedAt: null, cancelledAt: null,
        output: `[conf] echo: ${body.content ?? ''}`,
        terminal: false,
      })
      // Complete after 30ms
      setTimeout(() => {
        const r = store.get(executionId)!
        const done = new Date().toISOString()
        store.set(executionId, { ...r, state: 'COMPLETED', startedAt: done, completedAt: done, terminal: true })
      }, 30)
      return json(res, 202, {
        executionId, idempotencyKey: null, state: 'QUEUED',
        protocolVersion: proto, submittedAt: now, idempotent: false,
        // additive field — must be tolerated
        _conformanceTag: 'task-7',
      })
    }

    const m = url.match(/^\/v1\/executions\/([^/]+)(\/.*)?$/)
    if (!m) return json(res, 404, { code: 'NOT_FOUND', message: 'not found', protocolVersion: proto })

    const executionId = decodeURIComponent(m[1]!)
    const sub = m[2] ?? ''
    const record = store.get(executionId)

    if (!record) return json(res, 404, {
      code: 'EXECUTION_NOT_FOUND',
      message: `Execution ${executionId} not found`,
      executionId, protocolVersion: proto,
    })

    if (method === 'GET' && sub === '') {
      return json(res, 200, {
        executionId: record.executionId,
        state: record.state,
        protocolVersion: proto,
        submittedAt: record.submittedAt,
        startedAt: record.startedAt,
        completedAt: record.completedAt,
        cancelledAt: record.cancelledAt,
        terminal: record.terminal,
        // additive field — must be tolerated
        _revision: 1,
      })
    }

    if (method === 'GET' && sub === '/result') {
      if (!record.terminal) return json(res, 409, {
        code: 'RESULT_NOT_READY', message: 'not terminal', executionId, protocolVersion: proto,
      })
      return json(res, 200, {
        executionId: record.executionId, state: record.state, output: record.output,
        totalDurationMs: 30, completedAt: record.completedAt,
        // additive field
        _durationBreakdown: { plan: 5, exec: 25 },
      })
    }

    if (method === 'POST' && sub === '/cancel') {
      if (record.terminal) return json(res, 200, { executionId, state: record.state, cancelAccepted: false })
      const now = new Date().toISOString()
      store.set(executionId, { ...record, state: 'CANCELLED', cancelledAt: now, terminal: true })
      return json(res, 200, { executionId, state: 'CANCELLED', cancelAccepted: true })
    }

    if (method === 'GET' && sub === '/evidence') {
      return json(res, 200, {
        executionId,
        entries: [{ kind: 'step:completed', stepId: 'conf-step', detail: { ok: true }, recordedAt: new Date().toISOString() }],
        // additive field
        _evidenceVersion: 1,
      })
    }

    return json(res, 404, { code: 'NOT_FOUND', message: 'unknown sub-path', protocolVersion: proto })
  })

  await new Promise<void>(resolve => confServer.listen(CONF_PORT, '127.0.0.1', resolve))
})

afterAll(async () => {
  await new Promise<void>((resolve, reject) => confServer.close(err => err ? reject(err) : resolve()))
})

function client() {
  return createRohinikClient({ baseUrl: `http://127.0.0.1:${CONF_PORT}` })
}

async function pollTerminal(handle: ReturnType<typeof client>['executions']['attach'], maxMs = 2000) {
  return handle.waitUntilTerminal({ pollIntervalMs: 20, timeoutMs: maxMs })
}

// ── 1. Route shape conformance ────────────────────────────────────────────────

describe('Route shape conformance — POST /v1/executions', () => {
  it('returns 202 with all required SubmitExecutionResponse fields', async () => {
    const c = client()
    const handle = await c.executions.start({ content: 'shape test', contentType: 'TEXT' })
    expect(typeof handle.executionId).toBe('string')
    // ExecutionHandle was created from a valid SubmitExecutionResponse
    expect(handle.executionId).toMatch(/^conf-exec-/)
  })
})

describe('Route shape conformance — GET /v1/executions/:id', () => {
  it('returns all required ExecutionStatusResponse fields', async () => {
    const c = client()
    const handle = await c.executions.start({ content: 'status shape', contentType: 'TEXT' })
    const status = await handle.status()
    expect(typeof status.executionId).toBe('string')
    expect(typeof status.state).toBe('string')
    expect(status.protocolVersion).toBe('v1')
    expect(typeof status.submittedAt).toBe('string')
    expect(typeof status.terminal).toBe('boolean')
  })
})

describe('Route shape conformance — GET /v1/executions/:id/result', () => {
  it('returns all required ExecutionResultResponse fields after terminal', async () => {
    const c = client()
    const handle = await c.executions.start({ content: 'result shape', contentType: 'TEXT' })
    await pollTerminal(handle)
    const result = await handle.result()
    expect(result.executionId).toBe(handle.executionId)
    expect(typeof result.state).toBe('string')
    expect(typeof result.totalDurationMs).toBe('number')
    expect(typeof result.completedAt).toBe('string')
  })

  it('returns 409 RESULT_NOT_READY before terminal', async () => {
    const c = client()
    const handle = await c.executions.start({ content: 'result not ready', contentType: 'TEXT' })
    const status = await handle.status()
    if (!status.terminal) {
      await expect(handle.result()).rejects.toMatchObject({
        status: 409,
      })
    }
    // If already terminal due to fast mock, skip — race acceptable
  })
})

describe('Route shape conformance — POST /v1/executions/:id/cancel', () => {
  it('returns CancelExecutionResponse with cancelAccepted field', async () => {
    const c = client()
    const handle = await c.executions.start({ content: 'cancel shape', contentType: 'TEXT' })
    const resp = await handle.cancel({ reason: 'conformance test' })
    expect(resp.executionId).toBe(handle.executionId)
    expect(typeof resp.cancelAccepted).toBe('boolean')
  })

  it('cancel on terminal returns cancelAccepted=false', async () => {
    const c = client()
    const handle = await c.executions.start({ content: 'cancel terminal shape', contentType: 'TEXT' })
    await pollTerminal(handle)
    const resp = await handle.cancel()
    expect(resp.cancelAccepted).toBe(false)
  })
})

describe('Route shape conformance — GET /v1/executions/:id/evidence', () => {
  it('returns ExecutionEvidenceResponse with entries array', async () => {
    const c = client()
    const handle = await c.executions.start({ content: 'evidence shape', contentType: 'TEXT' })
    const ev = await handle.evidence()
    expect(ev.executionId).toBe(handle.executionId)
    expect(Array.isArray(ev.entries)).toBe(true)
    const entry = ev.entries[0]
    expect(entry).toBeDefined()
    expect(typeof entry!.kind).toBe('string')
    expect(typeof entry!.recordedAt).toBe('string')
  })
})

// ── 2. Forward-compatibility: additive fields tolerated ───────────────────────

describe('Forward-compatibility — additive fields', () => {
  it('unknown fields in SubmitExecutionResponse do not throw', async () => {
    const c = client()
    // Mock server adds _conformanceTag to 202 response — must not throw
    await expect(c.executions.start({ content: 'additive test', contentType: 'TEXT' })).resolves.toBeDefined()
  })

  it('unknown fields in status response do not throw', async () => {
    const c = client()
    const handle = await c.executions.start({ content: 'additive status', contentType: 'TEXT' })
    // Mock server adds _revision to status — must not throw
    await expect(handle.status()).resolves.toBeDefined()
  })

  it('unknown fields in result response do not throw', async () => {
    const c = client()
    const handle = await c.executions.start({ content: 'additive result', contentType: 'TEXT' })
    await pollTerminal(handle)
    // Mock server adds _durationBreakdown to result — must not throw
    await expect(handle.result()).resolves.toBeDefined()
  })

  it('unknown fields in evidence response do not throw', async () => {
    const c = client()
    const handle = await c.executions.start({ content: 'additive evidence', contentType: 'TEXT' })
    // Mock server adds _evidenceVersion to evidence — must not throw
    await expect(handle.evidence()).resolves.toBeDefined()
  })
})

// ── 3. Protocol version guard ─────────────────────────────────────────────────

describe('Protocol version guard', () => {
  it('throws ProtocolVersionError when server returns wrong protocolVersion', async () => {
    const wrongVersionServer = createServer((_req, res) => {
      const payload = JSON.stringify({
        executionId: 'x', idempotencyKey: null, state: 'QUEUED',
        protocolVersion: 'v999',  // wrong version
        submittedAt: new Date().toISOString(), idempotent: false,
      })
      res.writeHead(202, { 'Content-Type': 'application/json' })
      res.end(payload)
    })

    await new Promise<void>(r => wrongVersionServer.listen(19_203, '127.0.0.1', r))
    try {
      const c = createRohinikClient({ baseUrl: 'http://127.0.0.1:19203' })
      await expect(
        c.executions.start({ content: 'version test', contentType: 'TEXT' })
      ).rejects.toBeInstanceOf(ProtocolVersionError)
    } finally {
      await new Promise<void>((r, j) => wrongVersionServer.close(err => err ? j(err) : r()))
    }
  })
})

// ── 4. Error code coverage ────────────────────────────────────────────────────

describe('Error code recognition', () => {
  const allErrorCodes: PublicErrorCode[] = [
    'EXECUTION_NOT_FOUND',
    'RESULT_NOT_READY',
    'IDEMPOTENCY_CONFLICT',
    'INVALID_REQUEST',
    'INTERNAL_ERROR',
  ]

  it('all documented PublicErrorCode values parse into RohinikClientError.envelope', async () => {
    for (const code of allErrorCodes) {
      const errorServer = createServer((_req, res) => {
        const payload = JSON.stringify({
          code, message: `test error for ${code}`,
          protocolVersion: proto, executionId: 'test',
        })
        res.writeHead(409, { 'Content-Type': 'application/json' })
        res.end(payload)
      })
      const port = 19_204
      await new Promise<void>(r => errorServer.listen(port, '127.0.0.1', r))
      try {
        const c = createRohinikClient({ baseUrl: `http://127.0.0.1:${port}` })
        try {
          await c.executions.start({ content: 'x', contentType: 'TEXT' })
        } catch (err) {
          expect(err).toBeInstanceOf(RohinikClientError)
          expect((err as RohinikClientError).envelope?.code).toBe(code)
        }
      } finally {
        await new Promise<void>((r, j) => errorServer.close(err => err ? j(err) : r()))
      }
    }
  })

  it('404 for unknown executionId throws RohinikClientError with status 404', async () => {
    const c = client()
    const handle = c.executions.attach('does-not-exist')
    await expect(handle.status()).rejects.toMatchObject({ status: 404 })
  })
})

// ── 5. Packaging conformance — zero runtime dependencies ─────────────────────

describe('Packaging conformance', () => {
  it('packed @rohinik-org/client tarball declares no runtime dependencies', () => {
    // Reads the installed package.json from node_modules — reflects what consumers receive
    const pkgPath = resolve(process.cwd(), 'node_modules/@rohinik-org/client/package.json')
    let pkg: Record<string, unknown>
    try {
      pkg = JSON.parse(readFileSync(pkgPath, 'utf-8')) as Record<string, unknown>
    } catch {
      // When running tests in the SDK workspace, @rohinik-org/client is the current package
      const localPath = resolve(process.cwd(), 'package.json')
      pkg = JSON.parse(readFileSync(localPath, 'utf-8')) as Record<string, unknown>
    }
    const deps = (pkg.dependencies ?? {}) as Record<string, unknown>
    expect(Object.keys(deps)).toHaveLength(0)
  })

  it('EXECUTION_PROTOCOL_VERSION exported from SDK matches expected value', () => {
    expect(EXECUTION_PROTOCOL_VERSION).toBe('v1')
  })

  it('SDK exports all required protocol types (type-level check via import)', () => {
    // If any of these imports were missing, the TypeScript compile step would fail
    // This test proves the runtime module exports are present
    const mod = { createRohinikClient, RohinikClientError, ProtocolVersionError, EXECUTION_PROTOCOL_VERSION }
    expect(typeof mod.createRohinikClient).toBe('function')
    expect(typeof mod.RohinikClientError).toBe('function')
    expect(typeof mod.ProtocolVersionError).toBe('function')
    expect(typeof mod.EXECUTION_PROTOCOL_VERSION).toBe('string')
  })
})

// ── 6. waitForResult protocol conformance ────────────────────────────────────

describe('waitForResult protocol conformance', () => {
  it('full async lifecycle: start → waitForResult → result matches submission', async () => {
    const c = client()
    const content = 'full lifecycle conformance'
    const handle = await c.executions.start({ content, contentType: 'TEXT' })

    const result = await handle.waitForResult({ pollIntervalMs: 20, timeoutMs: 2000 })

    expect(result.executionId).toBe(handle.executionId)
    expect(result.output).toBe(`[conf] echo: ${content}`)
    expect(typeof result.totalDurationMs).toBe('number')
    expect(typeof result.completedAt).toBe('string')
  })

  it('cancel path: start → cancel → waitForResult throws ExecutionCancelledError', async () => {
    const { ExecutionCancelledError } = await import('../index.js')
    const c = client()
    const handle = await c.executions.start({ content: 'cancel conformance', contentType: 'TEXT' })
    // Cancel immediately — mock transitions to CANCELLED
    const cancelResp = await handle.cancel({ reason: 'conformance test' })
    if (cancelResp.cancelAccepted) {
      await expect(
        handle.waitForResult({ pollIntervalMs: 10, timeoutMs: 2000 })
      ).rejects.toBeInstanceOf(ExecutionCancelledError)
    }
    // If execution completed before cancel, cancelAccepted=false — valid race, no assertion
  })
})
